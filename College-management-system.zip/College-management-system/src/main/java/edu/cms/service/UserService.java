package edu.cms.service;

import edu.cms.entity.User;

public interface UserService {
 
	 User login(String userName, String password);
}
